const prod = require('~/dev.env');
if(prod == 'production'){
	var  proxy = ''
}else{
	var proxy = 'http://api.taokezhushou.com/api/v1'
}
console.log(proxy)
const appId = "c98d39b205c25a51";
module.exports = {
	getList(callback) {
		wx.request({
			url: proxy+"/search",
            data: {
                "app_key": appId,
            },
			method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
			// header: {}, // 设置请求的 header
			success: function (res) {
				// success
				callback(res.data);
			},
			fail: function () {
				// fail
			},
			complete: function () {
				// complete
			}
		})
	},
	detailApi() {
		wx.setStorageSync("sessionid", res.header["Set-Cookie"])
		wx.request({
			url:'http://www.taokezhushou.com/alimama',
			data: {
				'app_key':appId,
                'goods_id':'20555920246',
				'coupon_id':'06999cd930d7490289bf9c14e631a717',
				'text': '植美村旗舰店  植美村蜡菊日夜眼霜2支',
				'logo':'',
				'pid':'mm_132372115_45552774_622972830',
				'resp':'t',
            },
			method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
			// header: {}, // 设置请求的 header
			success: function (res) {
				// success
				callback(res.data);
			},
			fail: function () {
				// fail
			},
			complete: function () {
				// complete
			}
		})
	},
}
